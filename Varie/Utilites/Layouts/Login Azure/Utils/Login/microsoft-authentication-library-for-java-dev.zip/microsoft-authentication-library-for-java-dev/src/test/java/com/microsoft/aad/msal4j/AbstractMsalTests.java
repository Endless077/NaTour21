// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

package com.microsoft.aad.msal4j;

import org.powermock.modules.testng.PowerMockTestCase;

public class AbstractMsalTests extends PowerMockTestCase {
}
