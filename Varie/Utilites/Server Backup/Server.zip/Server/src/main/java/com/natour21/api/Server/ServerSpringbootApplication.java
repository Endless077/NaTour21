package com.natour21.api.Server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerSpringbootApplication.class, args);
	}

}
