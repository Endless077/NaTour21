package com.natour21.api.Server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
