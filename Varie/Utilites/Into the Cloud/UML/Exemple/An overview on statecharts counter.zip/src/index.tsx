import "./styles.css";
import * as React from "react";
import * as ReactDOM from "react-dom";
import { useMachine } from "@xstate/react";
import { counterMachine } from "./counterMachine";

const Counter = () => {
  const [state, send] = useMachine(counterMachine);

  return (
    <section>
      <h1>The Counter App</h1>
      <output>{state.context.count}</output>
      <button onClick={() => send("FLICK")}>Flick</button>
    </section>
  );
};

const App = () => {
  return <Counter />;
};

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
