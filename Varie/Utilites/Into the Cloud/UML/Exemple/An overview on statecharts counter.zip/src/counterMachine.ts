import { createMachine, assign } from "xstate";

interface CounterContext {
  count: number;
}

type CounterEvent = {
  type: "FLICK";
};

export const counterMachine = createMachine<CounterContext, CounterEvent>({
  initial: "increment",
  context: { count: 0 },
  states: {
    increment: {
      on: {
        FLICK: [
          {
            actions: assign({ count: (ctx) => ctx.count + 1 }),
            cond: (ctx) => ctx.count <= 10
          },
          {
            actions: assign({ count: (ctx) => ctx.count - 1 }),
            target: "decrement",
            cond: (ctx) => ctx.count > 10
          }
        ]
      }
    },
    decrement: {
      on: {
        FLICK: [
          {
            actions: assign({ count: (ctx) => ctx.count - 1 }),
            cond: (ctx) => ctx.count >= 0
          },
          {
            actions: assign({ count: (ctx) => ctx.count + 1 }),
            target: "increment",
            cond: (ctx) => ctx.count < 0
          }
        ]
      }
    }
  }
});
